﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ConsoleApp1
{
    class Task
    {
        public List<Smartphones> smartphones { get; set; } = new List<Smartphones>();
        public List<Headphones> headphones { get; set; } = new List<Headphones>();
        public List<Power_banks> power_banks { get; set; } = new List<Power_banks>();

        public Task()
        {
            download_smartphones();
            download_headphones();
            download_power_banks();
        }
        
        // Print

        public void print_menu()
        {
            for (; ; )
            {
                Console.Clear();
                Console.WriteLine("========Menu========");
                Console.WriteLine("[1]Print smartphones");
                Console.WriteLine("[2]Print headphones");
                Console.WriteLine("[3]Print power banks");
                Console.WriteLine("[4]Print all goods");
                Console.WriteLine("[~]Return");
                if (int.TryParse(Console.ReadLine(), out int number))
                {
                    Console.WriteLine();
                    if (number == 5)
                        return;

                    if (number >= 1 && number <= 4)
                    {
                        print_type(number);
                        return;
                    }
                }
                Console.Clear();
                Console.WriteLine("[!]The number is not correct, try again");
                Console.ReadLine();
                Console.Clear();
            }
        }

        private void print_type(int number)
        {
            for (; ; )
            {
                Console.Clear();
                Console.WriteLine("========Menu========");
                Console.WriteLine("[1]Print as a list");
                Console.WriteLine("[2]Print as a table");
                Console.WriteLine("[~]Return");
                if (int.TryParse(Console.ReadLine(), out int num))
                {
                    Console.WriteLine();
                    if (num == 3)
                        return;

                    if (num == 1)
                    {
                        if (number == 1)
                            print_list_smartphones();
                        if (number == 2)
                            print_list_headphones();
                        if (number == 3)
                            print_list_power_banks();
                        if (number == 4)
                            print_list_all();
                        return;
                    }

                    if (num == 2)
                    {
                        if (number == 1)
                            print_table_smartphones();
                        if (number == 2)
                            print_table_headphones();
                        if (number == 3)
                            print_table_power_banks();
                        if (number == 4)
                            print_table_all();
                        return;
                    }
                }
                Console.Clear();
                Console.WriteLine("[!]The number is not correct, try again");
                Console.ReadLine();
                Console.Clear();
            }
        }

        private void print_list_smartphones()
        {
            Console.Clear();
            count_smartphones();

            int s = 0;

            Console.WriteLine("========Info about smartphones========");
            foreach (var good in smartphones)
            {
                Console.WriteLine("Smartphone #" + (++s) + ":\n");
                good.output();
            }
            Console.WriteLine("======================================");
            Console.ReadLine();
            Console.Clear();
        }

        private void print_list_headphones()
        {
            Console.Clear();
            count_headphones();

            int h = 0;
            Console.WriteLine("========Info about headphones========");
            foreach (var good in headphones)
            {
                Console.WriteLine("Headphones #" + (++h) + ":\n");
                good.output();
            }
            Console.WriteLine("=====================================");
            Console.ReadLine();
            Console.Clear();
        }

        private void print_list_power_banks()
        {
            Console.Clear();
            count_power_banks();

            int p = 0;
            Console.WriteLine("=======Info about power banks=======");
            foreach (var good in power_banks)
            {
                Console.WriteLine("Power bank #" + (++p) + ":\n");
                good.output();
            }
            Console.WriteLine("==================================");
            Console.ReadLine();
            Console.Clear();
        }

        private void print_list_all()
        {
            Console.Clear();
            count_goods();

            int s = 0;
            int h = 0;
            int p = 0;
            Console.WriteLine("=======Info about all goods=======");
            foreach (var good in smartphones)
            {
                Console.WriteLine("Smartphone #" + (++s) + ":\n");
                good.output();
                Console.WriteLine("==================================");
            }
            foreach (var good in headphones)
            {
                Console.WriteLine("Headphones #" + (++h) + ":\n");
                good.output();
                Console.WriteLine("==================================");
            }

            foreach (var good in power_banks)
            {
                Console.WriteLine("Power bank #" + (++p) + ":\n");
                good.output();
                Console.WriteLine("==================================");
            }
            Console.ReadLine();
            Console.Clear();
        }

        private void print_table_smartphones()
        {
            Console.Clear();
            count_smartphones();

            int s = 0;
            Console.WriteLine("=========================================================================================Info about smartphones========================================================================================");
            foreach (var good in smartphones)
            {
                Console.WriteLine("Smartphone #" + (++s) + ":\n");
                Console.WriteLine(good.to_String());
            }
            Console.WriteLine("=======================================================================================================================================================================================================");
            Console.ReadLine();
            Console.Clear();
        }

        private void print_table_headphones()
        {
            Console.Clear();
            count_headphones();

            int h = 0;
            Console.WriteLine("=========================================================================================Info about headphones=======================================================================================");
            foreach (var good in headphones)
            {
                Console.WriteLine("Headphones #" + (++h) + ":\n");
                Console.WriteLine(good.to_String());
            }
            Console.WriteLine("=======================================================================================================================================================================================================");
            Console.ReadLine();
            Console.Clear();
        }

        private void print_table_power_banks()
        {
            Console.Clear();
            count_power_banks();

            int p = 0;
            Console.WriteLine("========================================================================================Info about power banks=======================================================================================");
            foreach (var good in power_banks)
            {
                Console.WriteLine("Power bank #" + (++p) + ":\n");
                Console.WriteLine(good.to_String());
            }
            Console.WriteLine("=======================================================================================================================================================================================================");
            Console.ReadLine();
            Console.Clear();
        }

        private void print_table_all()
        {
            Console.Clear();
            count_goods();

            int s = 0;
            int h = 0;
            int p = 0;
            Console.WriteLine("=========================================================================================Info about all goods========================================================================================");
            foreach (var good in smartphones)
            {
                Console.WriteLine("Smartphone #" + (++s) + ":\n");
                Console.WriteLine(good.to_String());
            }
            foreach (var good in headphones)
            {
                Console.WriteLine("Headphones #" + (++h) + ":\n");
                Console.WriteLine(good.to_String());
            }
            foreach (var good in power_banks)
            {
                Console.WriteLine("Power bank #" + (++p) + ":\n");
                Console.WriteLine(good.to_String());
            }
            Console.WriteLine("=======================================================================================================================================================================================================");
            Console.ReadLine();
            Console.Clear();
        }

        // Search

        public void search()
        {
            count_goods();
            Console.Clear();
            Console.Write("Enter the product model that you are looking for: ");
            string Model = Console.ReadLine();

            bool flag = false;
            int s = 0;
            int h = 0;
            int p = 0;
            Console.Clear();
            foreach (var good in smartphones)
            {
                if (good.model.Equals(Model))
                {
                    if (flag == false)
                    {
                        Console.WriteLine("================Result================");
                        flag = true;
                    }
                    Console.WriteLine("Smartphone #" + (++s) + ":\n");
                    good.output();
                    Console.WriteLine("======================================");
                }
            }
            foreach (var good in headphones)
            {
                if (good.model.Equals(Model))
                {
                    if (flag == false)
                    {
                        Console.WriteLine("================Result================");
                        flag = true;
                    }
                    Console.WriteLine("Headphones #" + (++h) + ":\n");
                    good.output();
                    Console.WriteLine("======================================");
                }
            }
            foreach (var good in power_banks)
            {
                if (good.model.Equals(Model))
                {
                    if (flag == false)
                    {
                        Console.WriteLine("================Result================");
                        flag = true;
                    }
                    Console.WriteLine("Power bank #" + (++p) + ":\n");
                    good.output();
                    Console.WriteLine("======================================");
                }
            }

            if (flag == false)
            {
                Console.WriteLine("[!]Search failed");
            }
            Console.ReadLine();
            Console.Clear();
        }

        // Sort

        public void sort_menu()
        {
            for (; ; )
            {
                Console.Clear();
                Console.WriteLine("========Menu========");
                Console.WriteLine("[1]Sort smartphones");
                Console.WriteLine("[2]Sort headphones");
                Console.WriteLine("[3]Sort power banks");
                Console.WriteLine("[~]Return");
                if (int.TryParse(Console.ReadLine(), out int number))
                {
                    if (number == 4)
                        return;

                    if (number == 1)
                    {
                        sort_smartphones();
                        Console.WriteLine();
                        return;
                    }

                    if (number == 2)
                    {
                        sort_headphones();
                        Console.WriteLine();
                        return;
                    }

                    if (number == 3)
                    {
                        sort_power_banks();
                        Console.WriteLine();
                        return;
                    }
                }
                Console.Clear();
                Console.WriteLine("[!]The number is not correct, try again\n");
                Console.ReadLine();
                Console.Clear();
            }
        }


        private void sort_smartphones()
        {
            count_smartphones();

            List<Smartphones> sortgoods = new List<Smartphones>(smartphones);

            for (int i = 1; i < sortgoods.Count; i++)
                for (int j = sortgoods.Count - 1; j >= i; j--)
                    if (sortgoods[i].price > sortgoods[j - 1].price)
                    {
                        Smartphones tmp = sortgoods[j - 1];
                        sortgoods[j - 1] = sortgoods[i];
                        sortgoods[i] = tmp;
                    }

            int s = 0;
            Console.Clear();
            Console.WriteLine("==============================================================================================Sorted list==============================================================================================");
            foreach (var good in sortgoods)
            {
                Console.WriteLine("Smartphone #" + (++s) + ":\n");
                Console.WriteLine(good.to_String());
            }
            Console.WriteLine("=======================================================================================================================================================================================================");
            Console.ReadLine();
            Console.Clear();
        }

        private void sort_headphones()
        {
            count_headphones();

            List<Headphones> sortgoods = new List<Headphones>(headphones);

            for (int i = 1; i < sortgoods.Count; i++)
                for (int j = sortgoods.Count - 1; j >= i; j--)
                    if (sortgoods[i].price > sortgoods[j - 1].price)
                    {
                        Headphones tmp = sortgoods[j - 1];
                        sortgoods[j - 1] = sortgoods[i];
                        sortgoods[i] = tmp;
                    }

            int h = 0;
            Console.Clear();
            Console.WriteLine("==============================================================================================Sorted list==============================================================================================");
            foreach (var good in sortgoods)
            {
                Console.WriteLine("Headphones #" + (++h) + ":\n");
                Console.WriteLine(good.to_String());
            }
            Console.WriteLine("=======================================================================================================================================================================================================");
            Console.ReadLine();
            Console.Clear();
        }

        private void sort_power_banks()
        {
            count_power_banks();

            List<Power_banks> sortgoods = new List<Power_banks>(power_banks);

            for (int i = 1; i < sortgoods.Count; i++)
                for (int j = sortgoods.Count - 1; j >= i; j--)
                    if (sortgoods[i].price > sortgoods[j - 1].price)
                    {
                        Power_banks tmp = sortgoods[j - 1];
                        sortgoods[j - 1] = sortgoods[i];
                        sortgoods[i] = tmp;
                    }

            int p = 0;
            Console.Clear();
            Console.WriteLine("==============================================================================================Sorted list==============================================================================================");
            foreach (var good in sortgoods)
            {
                Console.WriteLine("Power bank #" + (++p) + ":\n");
                Console.WriteLine(good.to_String());
            }
            Console.WriteLine("=======================================================================================================================================================================================================");
            Console.ReadLine();
            Console.Clear();
        }

        // Add

        public void add()
        {
            for (; ; )
            {
                Console.Clear();
                Console.WriteLine("=======Menu=======");
                Console.WriteLine("[1]Add smartphone");
                Console.WriteLine("[2]Add headphones");
                Console.WriteLine("[3]Add power bank");
                Console.WriteLine("[~]Return");
                if (int.TryParse(Console.ReadLine(), out int number))
                {
                    if (number == 4)
                        return;
                    if (number == 1 || number == 2 || number == 3)
                    {
                        Console.Clear();
                        Console.WriteLine("======Enter the info======");
                        if (number == 1)
                        {
                            Smartphones good = new Smartphones();
                            good.input();
                            smartphones.Add(good);

                            save_smartphones();
                        }

                        if (number == 2)
                        {
                            Headphones good = new Headphones();
                            good.input();
                            headphones.Add(good);

                            save_headphones();
                        }

                        if (number == 3)
                        {
                            Power_banks good = new Power_banks();
                            good.input();
                            power_banks.Add(good);

                            save_power_banks();
                        }

                        Console.WriteLine();
                        return;
                    }
                }
                Console.Clear();
                Console.WriteLine("[!]The number is not correct, try again");
                Console.ReadLine();
                Console.Clear();
            }
        }

        // Edit

        public void edit_menu()
        {
            for (; ; )
            {
                Console.Clear();
                Console.WriteLine("=======Menu=======");
                Console.WriteLine("[1]Edit smartphone");
                Console.WriteLine("[2]Edit headphones");
                Console.WriteLine("[3]Edit power bank");
                Console.WriteLine("[~]Return");
                if (int.TryParse(Console.ReadLine(), out int number))
                {
                    if (number == 4)
                        return;

                    Console.Clear();
                    Console.WriteLine("\n======Enter the info======");
                    if (number == 1)
                    {
                        edit_smartphones();
                        return;
                    }

                    if (number == 2)
                    {
                        edit_headphones();
                        return;
                    }

                    if (number == 3)
                    {
                        edit_power_banks();
                        return;
                    }
                }
                Console.Clear();
                Console.WriteLine("[!]The number is not correct, try again");
                Console.ReadLine();
                Console.Clear();
            }
        }

        private void edit_smartphones()
        {
            count_smartphones();

            Console.Clear();
            Console.Write("Enter the smartphone number that you want to edit: ");
            if (int.TryParse(Console.ReadLine(), out int number))
            {
                if (number <= 0 || number > smartphones.Count)
                {
                    Console.Clear();
                    Console.WriteLine("[!]The number is not correct, try again");
                    Console.ReadLine();
                    Console.Clear();
                    this.edit_smartphones();
                    return;
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("[!]The number is not correct, try again");
                Console.ReadLine();
                Console.Clear();
                this.edit_smartphones();
                return;
            }
            number--;
            Console.Clear();
            Console.WriteLine("======Edit======");
            smartphones[number].input();
            Console.WriteLine();

            save_smartphones();
        }

        private void edit_headphones()
        {
            count_headphones();

            Console.Clear();
            Console.Write("Enter the headphones number that you want to edit: ");
            if (int.TryParse(Console.ReadLine(), out int number))
            {
                if (number <= 0 || number > headphones.Count)
                {
                    Console.Clear();
                    Console.WriteLine("[!]The number is not correct, try again");
                    Console.ReadLine();
                    Console.Clear();
                    this.edit_headphones();
                    return;
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("[!]The number is not correct, try again");
                Console.ReadLine();
                Console.Clear();
                this.edit_headphones();
                return;
            }
            number--;
            Console.Clear();
            Console.WriteLine("======Edit======");
            headphones[number].input();

            save_headphones();
        }

        private void edit_power_banks()
        {
            count_power_banks();

            Console.Clear();
            Console.Write("Enter the power bank number that you want to edit: ");
            if (int.TryParse(Console.ReadLine(), out int number))
            {
                if (number <= 0 || number > power_banks.Count)
                {
                    Console.Clear();
                    Console.WriteLine("[!]The number is not correct, try again");
                    Console.ReadLine();
                    Console.Clear();
                    this.edit_power_banks();
                    return;
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("[!]The number is not correct, try again");
                Console.ReadLine();
                Console.Clear();
                this.edit_power_banks();
                return;
            }
            number--;
            Console.Clear();
            Console.WriteLine("======Edit======");
            power_banks[number].input();

            save_power_banks();
        }

        // Delete

        public void delete_menu()
        {
            for (; ; )
            {
                Console.Clear();
                Console.WriteLine("=======Menu=======");
                Console.WriteLine("[1]Delete smartphone");
                Console.WriteLine("[2]Delete headphones");
                Console.WriteLine("[3]Delete power bank");
                Console.WriteLine("[~]Return");
                if (int.TryParse(Console.ReadLine(), out int number))
                {
                    if (number == 4)
                        return;

                    if (number == 1)
                    {
                        delete_smartphones();
                        Console.WriteLine();
                        return;
                    }

                    if (number == 2)
                    {
                        delete_headphones();
                        Console.WriteLine();
                        return;
                    }

                    if (number == 3)
                    {
                        delete_power_banks();
                        Console.WriteLine();
                        return;
                    }
                }
                Console.Clear();
                Console.WriteLine("[!]The number is not correct, try again");
                Console.ReadLine();
                Console.Clear();
            }
        }

        private void delete_smartphones()
        {
            count_smartphones();

            Console.Clear();
            Console.Write("Enter the smartphone number that you want to delete: ");
            if (int.TryParse(Console.ReadLine(), out int number))
            {
                if (number <= 0 || number > smartphones.Count)
                {
                    Console.Clear();
                    Console.WriteLine("[!]The number is not correct, try again");
                    Console.ReadLine();
                    Console.Clear();
                    this.delete_smartphones();
                    return;
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("[!]The number is not correct, try again");
                Console.ReadLine();
                Console.Clear();
                this.delete_smartphones();
                return;
            }
            number--;

            smartphones.RemoveAt(number);
            Console.Clear();
            Console.WriteLine("[!]Removal was successful");
            Console.ReadLine();
            Console.Clear();

            save_smartphones();
        }

        private void delete_headphones()
        {
            count_headphones();

            Console.Clear();
            Console.Write("Enter the headphones number that you want to delete: ");
            if (int.TryParse(Console.ReadLine(), out int number))
            {
                if (number <= 0 || number > headphones.Count)
                {
                    Console.Clear();
                    Console.WriteLine("[!]The number is not correct, try again");
                    Console.ReadLine();
                    Console.Clear();
                    this.delete_headphones();
                    return;
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("[!]The number is not correct, try again");
                Console.ReadLine();
                Console.Clear();
                this.delete_headphones();
                return;
            }
            number--;

            headphones.RemoveAt(number);
            Console.Clear();
            Console.WriteLine("[!]Removal was successful");
            Console.ReadLine();
            Console.Clear();
            save_headphones();
        }

        private void delete_power_banks()
        {
            count_power_banks();
            
            Console.Clear();
            Console.Write("Enter the power bank number that you want to delete: ");
            if (int.TryParse(Console.ReadLine(), out int number))
            {
                if (number <= 0 || number > power_banks.Count)
                {
                    Console.Clear();
                    Console.WriteLine("[!]The number is not correct, try again");
                    Console.ReadLine();
                    Console.Clear();
                    this.delete_power_banks();
                    return;
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("[!]The number is not correct, try again");
                Console.ReadLine();
                Console.Clear();
                this.delete_power_banks();
                return;
            }
            number--;

            headphones.RemoveAt(number);
            Console.Clear();
            Console.WriteLine("[!]Removal was successful");
            Console.ReadLine();
            Console.Clear();

            save_power_banks();
        }

        // Check for records


        private void count_smartphones()
        {
            if (smartphones.Count == 0)
                throw new Exception("[!]No records");
        }
        private void count_headphones()
        {
            if (headphones.Count == 0)
                throw new Exception("[!]No records");
        }
        private void count_power_banks()
        {
            if (power_banks.Count == 0)
                throw new Exception("[!]No records");
        }
        private void count_goods()
        {
            if (smartphones.Count == 0 && headphones.Count == 0 && power_banks.Count == 0)
                throw new Exception("[!]No records");
        }

        // XML

        private void save_smartphones()
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<Smartphones>));

            using (FileStream fs = new FileStream("smartphones.xml", FileMode.Create))
            {
                xml.Serialize(fs, smartphones);
            }
        }

        private void save_headphones()
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<Headphones>));

            using (FileStream fs = new FileStream("headphones.xml", FileMode.Create))
            {
                xml.Serialize(fs, headphones);
            }
        }

        private void save_power_banks()
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<Power_banks>));

            using (FileStream fs = new FileStream("power_banks.xml", FileMode.Create))
            {
                xml.Serialize(fs, power_banks);
            }
        }

        private void download_smartphones()
        {
            try
            {
                XmlSerializer formatter = new XmlSerializer(typeof(List<Smartphones>));

                using (FileStream fs = new FileStream("smartphones.xml", FileMode.OpenOrCreate))
                {
                    smartphones = (List<Smartphones>)formatter.Deserialize(fs);
                }
            }
            catch (Exception ex)
            {
                //loger.Log("Read error!", MessageStatus.Warning);
            }
        }

        private void download_headphones()
        {
            try
            {
                XmlSerializer formatter = new XmlSerializer(typeof(List<Headphones>));

                using (FileStream fs = new FileStream("headphones.xml", FileMode.OpenOrCreate))
                {
                    headphones = (List<Headphones>)formatter.Deserialize(fs);
                }
            }
            catch (Exception ex)
            {
                //loger.Log("Read error!", MessageStatus.Warning);
            }
        }

        private void download_power_banks()
        {
            try
            {
                XmlSerializer formatter = new XmlSerializer(typeof(List<Power_banks>));

                using (FileStream fs = new FileStream("power_banks.xml", FileMode.OpenOrCreate))
                {
                    power_banks = (List<Power_banks>)formatter.Deserialize(fs);
                }
            }
            catch (Exception ex)
            {
                //loger.Log("Read error!", MessageStatus.Warning);
            }
        }
    }

}

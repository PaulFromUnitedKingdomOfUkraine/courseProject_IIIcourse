﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    [Serializable]
    public class Headphones : Goods
    {
        public string colour { get; set; }
        public string connector_type { get; set; }
        public string build_in_microphone { get; set; }

        public Headphones() : base()
        {
            colour = "";
            connector_type = "";
            build_in_microphone = "";
        }

        public Headphones(string brand, string model, int amount, double price, string colour, string connector_type, string build_in_microphone)
            : base(brand, model, amount, price)
        {
            this.colour = colour;
            this.connector_type = connector_type;
            this.build_in_microphone = build_in_microphone;
        }

        public override void input()
        {
            base.input();
            Console.Write("Colour: ");
            colour = Console.ReadLine();
            Console.Write("Connector type: ");
            connector_type = Console.ReadLine();
            Console.Write("Build-in microphone: ");
            build_in_microphone = Console.ReadLine();
        }

        public override void output()
        {
            base.output();
            Console.WriteLine("Colour - " + colour);
            Console.WriteLine("Connector type - " + connector_type);
            Console.WriteLine("Build-in microphone - " + build_in_microphone + "\n");
        }

        public override String to_String()
        {
            return base.to_String() + "\nColour: " + colour + "\tConnector type: " + connector_type + "\tBuild-in microphone: " + build_in_microphone + "\n";
        }
    }
}

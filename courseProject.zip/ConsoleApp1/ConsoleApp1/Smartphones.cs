﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    [Serializable]
    public class Smartphones : Goods
    {
        public string operating_system { get; set; }
        public string processor { get; set; }
        public int vertical_resolution { get; set; }
        public int horizontal_resolution { get; set; }
        public int random_access_memory { get; set; }
        public int memory_storage { get; set; }
        public int main_camera { get; set; }
        public int front_camera { get; set; }
        public int battery_capacity { get; set; }

        public Smartphones() : base()
        {
            operating_system = "";
            processor = "";
            vertical_resolution = 0;
            horizontal_resolution = 0;
            random_access_memory = 0;
            memory_storage = 0;
            main_camera = 0;
            front_camera = 0;
            battery_capacity = 0;
        }

        public Smartphones(string brand, string model, int amount, double price, string operating_system, string processor, int vertical_resolution, int horizontal_resolution, int random_access_memory, int memory_storage, int main_camera, int front_camera, int battery_capacity) 
            : base(brand, model, amount, price)
        {
            this.operating_system = operating_system;
            this.processor = processor;
            this.vertical_resolution = vertical_resolution;
            this.horizontal_resolution = horizontal_resolution;
            this.random_access_memory = random_access_memory;
            this.memory_storage = memory_storage;
            this.main_camera = main_camera;
            this.front_camera = front_camera;
            this.battery_capacity = battery_capacity;
        }

        public override void input()
        {
            base.input();
            Console.Write("OS: ");
            operating_system = Console.ReadLine();
            Console.Write("Processor: ");
            processor = Console.ReadLine();
            Console.Write("Vertical resolution: ");
            vertical_resolution = int.Parse(Console.ReadLine());
            Console.Write("Horizontal resolution: ");
            horizontal_resolution = int.Parse(Console.ReadLine());
            Console.Write("RAM(GB): ");
            random_access_memory = int.Parse(Console.ReadLine());
            Console.Write("Memory storage(GB): ");
            memory_storage = int.Parse(Console.ReadLine());
            Console.Write("Main camera(MP): ");
            main_camera = int.Parse(Console.ReadLine());
            Console.Write("Front camera(MP): ");
            front_camera = int.Parse(Console.ReadLine());
            Console.Write("Battery capacity(mAh): ");
            battery_capacity = int.Parse(Console.ReadLine());
        }

        public override void output()
        {
            base.output();
            Console.WriteLine("OS - " + operating_system);
            Console.WriteLine("Processor - " + processor);
            Console.WriteLine("Resolution - " + vertical_resolution + "x" + horizontal_resolution);
            Console.WriteLine("RAM - " + random_access_memory + "GB");
            Console.WriteLine("Memory storage - " + memory_storage + "GB");
            Console.WriteLine("Main camera - " + main_camera + "MP");
            Console.WriteLine("Front camera - " + front_camera + "MP");
            Console.WriteLine("Battery capacity - " + battery_capacity + "mAh\n");
        }

        public override String to_String()
        {
            return base.to_String() + "\nOS: " + operating_system + "\tProcessor: " + processor + "\tResolution: " + vertical_resolution + "x" + horizontal_resolution + "\tRAM: " + random_access_memory + "GB\tMemory storage: " + memory_storage + "GB\tMain camera: " + main_camera + "MP\tFront camera: " + front_camera + "MP\tBattery capacity: " + battery_capacity + "mAh\n";
        }
    }
}

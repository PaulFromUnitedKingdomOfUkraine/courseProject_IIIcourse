﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static string name = "";
        static string surname = "";
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.Default;

            Task tasks = new Task();
            for (; ; )
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("====mainMenu====");
                    Console.WriteLine("[1]User mode");
                    Console.WriteLine("[2]Admin mode");
                    Console.WriteLine("[~]Close program");
                    if (int.TryParse(Console.ReadLine(), out int number))
                    {
                        Console.WriteLine();
                        switch (number)
                        {
                            case 1:
                                for (; ; )
                                {
                                    Console.Clear();
                                    if (!name.Trim().Equals("") && !surname.Trim().Equals(""))
                                    {
                                        Console.WriteLine("Welcome " + surname + " " + name + "!");
                                        Console.WriteLine();
                                        UserMenu();
                                        break;
                                    }

                                    Console.Write("Enter surname: ");
                                    surname = Console.ReadLine();
                                    Console.Write("Enter name: ");
                                    name = Console.ReadLine();

                                    if (!name.Trim().Equals("") && !surname.Trim().Equals(""))
                                    {
                                        Console.Clear();
                                        Console.WriteLine("[!]Welcome " + surname + " " + name + "!");
                                        Console.ReadLine();
                                        Console.Clear();
                                        UserMenu();
                                        break;
                                    }
                                }
                                break;
                            case 2:
                                for (; ; )
                                {
                                    Console.Clear();
                                    Console.Write("Login: ");
                                    string login = Console.ReadLine();
                                    Console.Write("Password: ");
                                    string password = Console.ReadLine();

                                    if (login.Trim().Equals("qwerty") && password.Trim().Equals("12345"))
                                    {
                                        Console.WriteLine();
                                        AdminMenu();
                                        break;
                                    }
                                    else Console.Clear();
                                    Console.WriteLine("[!]Wrong login or password!");
                                    Console.ReadLine();
                                    Console.Clear();
                                }
                                break;
                            case 3:
                                return;
                            default:
                                Console.Clear();
                                Console.WriteLine("[!]Entered number is invalid, try again");
                                Console.ReadLine();
                                Console.Clear();
                                break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private static void AdminMenu()
        {
            Task task = new Task();
            for (; ; )
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("=============adminMenu=============");
                    Console.WriteLine("Type \"print\" to print goods");
                    Console.WriteLine("Type \"search\" to find a good");
                    Console.WriteLine("Type \"sort\" to sort goods");
                    Console.WriteLine("Type \"add\" to add a good");
                    Console.WriteLine("Type \"edit\" to edit a good");
                    Console.WriteLine("Type \"delete\" to delete a good");
                    Console.WriteLine("Type \"exit\" to return to main menu");
                    string command = Console.ReadLine();

                    switch (command)
                    {
                        case "print":
                            task.print_menu();
                            break;
                        case "search":
                            task.search();
                            break;
                        case "sort":
                            task.sort_menu();
                            break;
                        case "add":
                            task.add();
                            break;
                        case "edit":
                            task.edit_menu();
                            break;
                        case "delete":
                            task.delete_menu();
                            break;
                        case "exit":
                            return;
                        default:
                            Console.Clear();
                            Console.WriteLine("[!]The command is invalid, try again");
                            Console.ReadLine();
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private static void UserMenu()
        {
            Task task = new Task();
            for (; ; )
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("=============userMenu=============");
                    Console.WriteLine("Type \"print\" to print goods");
                    Console.WriteLine("Type \"search\" to find a good");
                    Console.WriteLine("Type \"sort\" to sort goods");
                    Console.WriteLine("Type \"exit\" to return to main menu");
                    string command = Console.ReadLine();

                    switch (command)
                    {
                        case "print":
                            task.print_menu();
                            break;
                        case "search":
                            task.search();
                            break;
                        case "sort":
                            task.sort_menu();
                            break;
                        case "exit":
                            return;
                            break;
                        default:
                            Console.Clear();
                            Console.WriteLine("[!]The command is invalid, try again");
                            Console.ReadLine();
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                Console.WriteLine();
            }
        }
    }
}

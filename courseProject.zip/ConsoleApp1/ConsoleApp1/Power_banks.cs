﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    [Serializable]
    public class Power_banks : Goods
    {
        public string connector_type { get; set; }
        public int battery_capacity { get; set; }
        public int item_dimension_length { get; set; }
        public int item_dimension_width { get; set; }
        public int item_dimension_height { get; set; }

        public Power_banks() : base()
        {
            connector_type = "";
            battery_capacity = 0;
            item_dimension_length = 0;
            item_dimension_width = 0;
            item_dimension_height = 0;
        }

        public Power_banks(string brand, string model, int amount, double price, string connector_type, int battery_capacity, int item_dimension_length, int item_dimension_width, int item_dimension_height)
            : base(brand, model, amount, price)
        {
            this.connector_type = connector_type;
            this.battery_capacity = battery_capacity;
            this.item_dimension_length = item_dimension_length;
            this.item_dimension_width = item_dimension_width;
            this.item_dimension_height = item_dimension_height;
        }

        public override void input()
        {
            base.input();
            Console.Write("Connector type: ");
            connector_type = Console.ReadLine();
            Console.Write("Battery capacity(mAh): ");
            battery_capacity = int.Parse(Console.ReadLine());
            Console.Write("Item dimension length(mm): ");
            item_dimension_length = int.Parse(Console.ReadLine());
            Console.Write("Item dimension width(mm): ");
            item_dimension_width = int.Parse(Console.ReadLine());
            Console.Write("Item dimension height(mm): ");
            item_dimension_height = int.Parse(Console.ReadLine());
        }
        public override void output()
        {
            base.output();
            Console.WriteLine("Connector type - " + connector_type);
            Console.WriteLine("Battery capacity - " + battery_capacity + "mAh");
            Console.WriteLine("Item dimensions - " + item_dimension_length + "x" + item_dimension_width + "x" + item_dimension_height + "mm\n");
        }

        public override String to_String()
        {
            return base.to_String() + "\nConnector type: " + connector_type + "\tBattery capacity: " + battery_capacity + "mAh\tItem dimensions: " + item_dimension_length + "x" + item_dimension_width + "x" + item_dimension_height + "mm\n";
        }
    }
}

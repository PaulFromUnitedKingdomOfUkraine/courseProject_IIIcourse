﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    [Serializable]
    public class Goods
    {
        public string brand { get; set; }
        public string model { get; set; }
        public int amount { get; set; }
        public double price { get; set; }

        public Goods()
        {
            brand = "";
            model = "";
            amount = 0;
            price = 0;
        }

        public Goods(string brand, string model, int amount, double price)
        {
            this.brand = brand;
            this.model = model;
            this.amount = amount;
            this.price = price;
        }

        public virtual void input()
        {
            Console.Write("Brand: ");
            brand = Console.ReadLine();
            Console.Write("Model: ");
            model = Console.ReadLine();
            Console.Write("Amount: ");
            amount = int.Parse(Console.ReadLine());
            Console.Write("Price: ");
            price = double.Parse(Console.ReadLine());
        }

        public virtual void output()
        {
            Console.WriteLine("Brand - " + brand);
            Console.WriteLine("Model - " + model);
            Console.WriteLine("Amount - " + amount);
            Console.WriteLine("Price - " + price + " grn.");
        }

        public virtual String to_String()
        {
            return "Brand: " + brand + "\tModel: " + model + "\tAmount: " + amount + "\tPrice:" + price + " grn.";
        }
    }
}
